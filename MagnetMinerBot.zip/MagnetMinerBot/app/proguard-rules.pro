# Keep accessibility service
-keep class com.magnetminer.bot.service.AutoClickAccessibilityService { *; }
-keep class com.magnetminer.bot.service.OverlayService { *; }
-keep class com.magnetminer.bot.utils.BootReceiver { *; }
