package com.magnetminer.bot.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.magnetminer.bot.utils.BotPreferences
import com.magnetminer.bot.utils.BotState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Core AccessibilityService.
 *
 * Strategy:
 *  1. Every [scanInterval] ms the service walks the accessibility node tree
 *     looking for nodes whose text matches one of the configured target labels.
 *  2. When a match is found and [BotState.isRunning] is true, it performs a
 *     click gesture at the node's on-screen bounds centre.
 *  3. A configurable [tapInterval] cooldown prevents hammer-clicking the same
 *     button before the UI has time to react.
 */
class AutoClickAccessibilityService : AccessibilityService() {

    companion object {
        /** Broadcast action sent by OverlayService / MainActivity to toggle running state. */
        const val ACTION_START = "com.magnetminer.bot.START"
        const val ACTION_STOP  = "com.magnetminer.bot.STOP"

        @Volatile
        var instance: AutoClickAccessibilityService? = null
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())

    private var scanJob: Job? = null
    private var lastTapTimeMs = 0L

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        BotState.appendLog("Accessibility service connected.")
    }

    override fun onInterrupt() {
        BotState.appendLog("Accessibility service interrupted.")
    }

    override fun onDestroy() {
        super.onDestroy()
        stopScanning()
        instance = null
        BotState.appendLog("Accessibility service destroyed.")
    }

    // -------------------------------------------------------------------------
    // Broadcast / Intent handling
    // -------------------------------------------------------------------------

    override fun onUnbind(intent: Intent?): Boolean {
        stopScanning()
        return super.onUnbind(intent)
    }

    // -------------------------------------------------------------------------
    // Accessibility events – also used as an entry point for scanning
    // -------------------------------------------------------------------------

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!BotState.isRunning.value) return
        // Scanning is driven by the coroutine loop; individual events provide
        // an additional trigger to react faster when a new window appears.
        when (event?.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> scanOnce()
            else -> Unit
        }
    }

    // -------------------------------------------------------------------------
    // Public API called by OverlayService
    // -------------------------------------------------------------------------

    fun startBot() {
        BotState.setRunning(true)
        BotState.appendLog("Bot started.")
        startScanning()
    }

    fun stopBot() {
        BotState.setRunning(false)
        stopScanning()
        BotState.appendLog("Bot stopped.")
    }

    // -------------------------------------------------------------------------
    // Scanning loop
    // -------------------------------------------------------------------------

    private fun startScanning() {
        scanJob?.cancel()
        scanJob = serviceScope.launch {
            while (BotState.isRunning.value) {
                scanOnce()
                val interval = BotPreferences.getScanIntervalMs(this@AutoClickAccessibilityService)
                delay(interval)
            }
        }
    }

    private fun stopScanning() {
        scanJob?.cancel()
        scanJob = null
    }

    private fun scanOnce() {
        val root = rootInActiveWindow ?: return
        val enabledLabels = BotPreferences.getEnabledLabels(this)
        val tapInterval = BotPreferences.getTapIntervalMs(this)

        val now = System.currentTimeMillis()
        if (now - lastTapTimeMs < tapInterval) return   // still in cooldown

        findAndClick(root, enabledLabels, now)
        root.recycle()
    }

    /**
     * DFS walk of the node tree. Clicks the FIRST matching node and returns.
     */
    private fun findAndClick(
        node: AccessibilityNodeInfo,
        labels: Set<String>,
        now: Long
    ): Boolean {
        val nodeText = node.text?.toString()?.trim() ?: ""
        val nodeDesc = node.contentDescription?.toString()?.trim() ?: ""

        val matched = labels.firstOrNull { label ->
            nodeText.equals(label, ignoreCase = true) ||
            nodeDesc.equals(label, ignoreCase = true) ||
            nodeText.contains(label, ignoreCase = true)
        }

        if (matched != null && (node.isClickable || hasClickableParent(node))) {
            val bounds = android.graphics.Rect()
            node.getBoundsInScreen(bounds)
            if (!bounds.isEmpty) {
                val cx = bounds.centerX().toFloat()
                val cy = bounds.centerY().toFloat()
                performTapGesture(cx, cy)
                lastTapTimeMs = now
                BotState.recordTap(matched)
                return true
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findAndClick(child, labels, now)
            child.recycle()
            if (found) return true
        }
        return false
    }

    private fun hasClickableParent(node: AccessibilityNodeInfo): Boolean {
        var parent = node.parent ?: return false
        return try {
            parent.isClickable
        } finally {
            parent.recycle()
        }
    }

    // -------------------------------------------------------------------------
    // Gesture dispatch
    // -------------------------------------------------------------------------

    private fun performTapGesture(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 50L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}
