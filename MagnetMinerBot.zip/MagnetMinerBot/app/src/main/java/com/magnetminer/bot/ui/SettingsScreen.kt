package com.magnetminer.bot.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.magnetminer.bot.utils.BotPreferences

/**
 * Settings screen – tap interval, scan interval, enabled labels.
 * All changes are persisted to SharedPreferences immediately.
 */
@Composable
fun SettingsScreen() {
    val context = LocalContext.current

    // ── State ────────────────────────────────────────────────────────────────
    var tapIntervalMs by remember {
        mutableStateOf(BotPreferences.getTapIntervalMs(context))
    }
    var scanIntervalMs by remember {
        mutableStateOf(BotPreferences.getScanIntervalMs(context))
    }
    val allLabels = BotPreferences.DEFAULT_LABELS
    val enabledLabels = remember {
        mutableStateOf(BotPreferences.getEnabledLabels(context).toMutableSet())
    }

    // ── UI ───────────────────────────────────────────────────────────────────
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text(
            text = "Settings",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        // ── Tap Interval ─────────────────────────────────────────────────────
        SectionCard(title = "Tap Cooldown") {
            Text("After a successful tap, wait this many ms before the next tap.", fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            SliderRow(
                label = "Tap interval",
                value = tapIntervalMs,
                range = 100f..2000f,
                onValueChange = {
                    tapIntervalMs = it
                    BotPreferences.setTapIntervalMs(context, it)
                }
            )
        }

        // ── Scan Interval ────────────────────────────────────────────────────
        SectionCard(title = "Scan Interval") {
            Text("How often the accessibility tree is scanned for target buttons.", fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            SliderRow(
                label = "Scan interval",
                value = scanIntervalMs,
                range = 100f..1000f,
                onValueChange = {
                    scanIntervalMs = it
                    BotPreferences.setScanIntervalMs(context, it)
                }
            )
        }

        // ── Target Labels ─────────────────────────────────────────────────────
        SectionCard(title = "Target Button Labels") {
            Text("Toggle which button texts the bot should look for and click.", fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            allLabels.forEach { label ->
                val checked = label in enabledLabels.value
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                ) {
                    Checkbox(
                        checked = checked,
                        onCheckedChange = { isChecked ->
                            val updated = enabledLabels.value.toMutableSet()
                            if (isChecked) updated.add(label) else updated.remove(label)
                            enabledLabels.value = updated
                            BotPreferences.setEnabledLabels(context, updated)
                        }
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(label, fontSize = 15.sp)
                }
            }
        }
    }
}

// ── Reusable composables ──────────────────────────────────────────────────────

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun SliderRow(
    label: String,
    value: Long,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Long) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text("${value} ms", fontSize = 13.sp, modifier = Modifier.width(68.dp))
        Slider(
            value = value.toFloat(),
            onValueChange = { onValueChange(it.toLong()) },
            valueRange = range,
            steps = ((range.endInclusive - range.start) / 100).toInt() - 1,
            modifier = Modifier.weight(1f)
        )
    }
}
