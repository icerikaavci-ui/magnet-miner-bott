package com.magnetminer.bot.utils

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Optionally re-start the OverlayService after device reboot
 * (user must have previously granted overlay permission).
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Only restart if user left the bot "armed" – implement a flag if desired.
            // For safety we do nothing automatically; user must open the app.
        }
    }
}
