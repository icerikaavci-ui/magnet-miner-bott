package com.magnetminer.bot.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.magnetminer.bot.service.AutoClickAccessibilityService
import com.magnetminer.bot.service.OverlayService
import com.magnetminer.bot.utils.BotState
import kotlinx.coroutines.launch

@Composable
fun HomeScreen() {
    val context = LocalContext.current
    val isRunning by BotState.isRunning.collectAsState()
    val tapCount by BotState.tapCount.collectAsState()
    val lastLabel by BotState.lastTappedLabel.collectAsState()
    val logLines by BotState.logLines.collectAsState()

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    // Auto-scroll log to bottom on new entries
    LaunchedEffect(logLines.size) {
        if (logLines.isNotEmpty()) {
            coroutineScope.launch { listState.animateScrollToItem(logLines.size - 1) }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ── Header ────────────────────────────────────────────────────────────
        Text(
            "Magnet Miner Bot",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )

        // ── Status card ───────────────────────────────────────────────────────
        StatusCard(isRunning = isRunning, tapCount = tapCount, lastLabel = lastLabel)

        // ── Accessibility check ───────────────────────────────────────────────
        val a11yEnabled = AutoClickAccessibilityService.instance != null
        if (!a11yEnabled) {
            AccessibilityWarning(onOpenSettings = {
                context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
        }

        // ── Start / Stop overlay button ───────────────────────────────────────
        Button(
            onClick = {
                if (!Settings.canDrawOverlays(context)) {
                    context.startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        )
                    )
                    return@Button
                }
                val intent = Intent(context, OverlayService::class.java)
                context.startForegroundService(intent)
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Show Floating Overlay")
        }

        // ── Log ───────────────────────────────────────────────────────────────
        Text("Activity Log", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        Card(
            modifier = Modifier.fillMaxWidth().weight(1f),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E))
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                items(logLines) { line ->
                    Text(line, color = Color(0xFF80FF80), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
                if (logLines.isEmpty()) {
                    item {
                        Text(
                            "No activity yet. Start the bot to see logs here.",
                            color = Color(0xFF777777), fontSize = 12.sp, fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusCard(isRunning: Boolean, tapCount: Int, lastLabel: String) {
    val bgColor by animateColorAsState(
        targetValue = if (isRunning) Color(0xFF1B5E20) else Color(0xFF212121),
        label = "statusBg"
    )
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = if (isRunning) "● Running" else "○ Stopped",
                    color = if (isRunning) Color(0xFF69F0AE) else Color(0xFFBBBBBB),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Spacer(Modifier.height(4.dp))
                Text("Taps: $tapCount", color = Color.White, fontSize = 14.sp)
                if (lastLabel.isNotBlank()) {
                    Text("Last: $lastLabel", color = Color(0xFFBBBBBB), fontSize = 12.sp)
                }
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(
                        color = if (isRunning) Color(0xFF43A047) else Color(0xFF424242),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = Color.White
                )
            }
        }
    }
}

@Composable
private fun AccessibilityWarning(onOpenSettings: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFB71C1C))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "⚠ Accessibility Service not enabled.",
                color = Color.White,
                modifier = Modifier.weight(1f),
                fontSize = 13.sp
            )
            TextButton(onClick = onOpenSettings) {
                Text("Enable", color = Color(0xFFFFCDD2))
            }
        }
    }
}
