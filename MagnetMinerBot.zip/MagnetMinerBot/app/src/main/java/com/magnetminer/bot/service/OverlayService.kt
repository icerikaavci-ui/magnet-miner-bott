package com.magnetminer.bot.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.magnetminer.bot.MainActivity
import com.magnetminer.bot.R
import com.magnetminer.bot.utils.BotState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Foreground service that draws a draggable floating overlay button.
 * Tapping the button toggles the bot on/off via [AutoClickAccessibilityService].
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_START_OVERLAY = "com.magnetminer.bot.START_OVERLAY"
        const val ACTION_STOP_OVERLAY  = "com.magnetminer.bot.STOP_OVERLAY"
        const val CHANNEL_ID = "magnet_miner_bot_channel"
        const val NOTIF_ID = 1
    }

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        addOverlayView()
        observeBotState()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_OVERLAY -> {
                stopSelf()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        overlayView?.let { windowManager.removeView(it) }
        overlayView = null
        // Ensure bot is stopped when overlay is dismissed
        AutoClickAccessibilityService.instance?.stopBot()
        BotState.setRunning(false)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // -------------------------------------------------------------------------
    // Overlay
    // -------------------------------------------------------------------------

    private fun addOverlayView() {
        val layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 200
        }

        // Root container
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 4, 4, 4)
        }

        // Status label
        val statusLabel = TextView(this).apply {
            text = "⏹ Stopped"
            setTextColor(Color.WHITE)
            textSize = 11f
            gravity = Gravity.CENTER_HORIZONTAL
        }

        // Play/Stop button
        val toggleButton = createCircleButton()

        container.addView(statusLabel)
        container.addView(toggleButton)

        // Dragging logic
        var initialX = 0; var initialY = 0
        var touchX = 0f; var touchY = 0f
        var isDragging = false

        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (!isDragging && (Math.abs(dx) > 10 || Math.abs(dy) > 10)) {
                        isDragging = true
                    }
                    if (isDragging) {
                        params.x = initialX + dx
                        params.y = initialY + dy
                        windowManager.updateViewLayout(container, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        // Toggle bot
                        val svc = AutoClickAccessibilityService.instance
                        if (svc == null) {
                            statusLabel.text = "⚠ Enable\nA11y first"
                        } else if (BotState.isRunning.value) {
                            svc.stopBot()
                        } else {
                            svc.startBot()
                        }
                    }
                    true
                }
                else -> false
            }
        }

        // Observe state to update button appearance
        scope.launch {
            BotState.isRunning.collectLatest { running ->
                toggleButton.setBackgroundColor(if (running) Color.parseColor("#E53935") else Color.parseColor("#43A047"))
                statusLabel.text = if (running) "▶ Running" else "⏹ Stopped"
            }
        }

        overlayView = container
        windowManager.addView(container, params)
    }

    private fun createCircleButton(): View {
        return TextView(this).apply {
            text = "BOT"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#43A047"))
            val size = (64 * resources.displayMetrics.density).toInt()
            layoutParams = LinearLayout.LayoutParams(size, size)
            setPadding(8, 8, 8, 8)
        }
    }

    // -------------------------------------------------------------------------
    // State observer
    // -------------------------------------------------------------------------

    private fun observeBotState() {
        scope.launch {
            BotState.tapCount.collectLatest { count ->
                // Update notification text with tap count
                val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(NOTIF_ID, buildNotification(count))
            }
        }
    }

    // -------------------------------------------------------------------------
    // Notification
    // -------------------------------------------------------------------------

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Magnet Miner Bot status"
            setShowBadge(false)
        }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(tapCount: Int = 0): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).apply { action = ACTION_STOP_OVERLAY },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText("Taps: $tapCount")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_delete, "Stop Overlay", stopIntent)
            .setOngoing(true)
            .build()
    }
}
