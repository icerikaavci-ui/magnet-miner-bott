# Magnet Miner Bot 🤖⛏️

An Android automation bot for **Magnet Miner Winter Edition** built with Kotlin,
Jetpack Compose, and Android Accessibility Service.

---

## Architecture

```
com.magnetminer.bot
├── MainActivity.kt                  ← Single-activity shell + bottom nav
├── ui/
│   ├── HomeScreen.kt                ← Status card, overlay launcher, live log
│   └── SettingsScreen.kt            ← Tap interval, scan interval, label toggles
├── service/
│   ├── AutoClickAccessibilityService.kt  ← Core a11y service; walks node tree & taps
│   └── OverlayService.kt            ← Foreground service; floating draggable button
└── utils/
    ├── BotState.kt                  ← StateFlow singleton shared across components
    ├── BotPreferences.kt            ← SharedPreferences helper
    └── BootReceiver.kt              ← BroadcastReceiver for BOOT_COMPLETED
```

---

## Features

| Feature | Detail |
|---------|--------|
| Button detection | Matches: **Play · Claim · Collect · Continue · Reward · X3** (case-insensitive, partial match) |
| Tap gesture | `GestureDescription` dispatched at node bounds centre |
| Floating overlay | Draggable BOT button; green = idle, red = running |
| Tap cooldown | Configurable 100–2000 ms (default 500 ms) |
| Scan interval | Configurable 100–1000 ms (default 300 ms) |
| Live log | Last 50 events streamed into a terminal-style card |
| Background | Foreground service keeps overlay alive while app is backgrounded |
| Notifications | Shows tap count; one-tap "Stop Overlay" action |

---

## Setup & Installation

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or later  
- Android SDK 34  
- Physical device or emulator running API 26+

### Steps
1. Clone / unzip the project.
2. Open the project root in Android Studio.
3. Run `./gradlew assembleDebug` or press ▶ in the IDE.
4. Install the APK on your device.

### First-run configuration
1. Open **Magnet Miner Bot**.
2. Tap the red banner → opens **Accessibility Settings** → enable
   `Magnet Miner Auto-Click`.
3. Back in the app, tap **Show Floating Overlay**.  
   If prompted, grant "Display over other apps" permission.
4. Open **Magnet Miner Winter Edition**.
5. Tap the **BOT** floating button to start auto-clicking.

---

## Permissions explained

| Permission | Why |
|------------|-----|
| `SYSTEM_ALERT_WINDOW` | Draw the floating overlay above other apps |
| `FOREGROUND_SERVICE` | Keep `OverlayService` alive while the screen is on |
| `FOREGROUND_SERVICE_SPECIAL_USE` | Required on API 34+ for `specialUse` service type |
| `POST_NOTIFICATIONS` | Show the persistent status notification |
| `RECEIVE_BOOT_COMPLETED` | (Optional) Re-arm the bot after reboot |

---

## Customisation

### Add more target labels
Edit `BotPreferences.DEFAULT_LABELS` in `utils/BotPreferences.kt`:

```kotlin
val DEFAULT_LABELS = listOf("Play", "Claim", "Collect", "Continue", "Reward", "X3", "Spin")
```

### Target a different package
Edit `android:packageNames` in `res/xml/accessibility_service_config.xml`:

```xml
android:packageNames="com.example.othergame"
```

Remove the attribute entirely to scan **all** packages.

---

## Notes

- The accessibility service is sandboxed to the Magnet Miner package by default.  
  Remove `android:packageNames` in the config to work with any app.
- `GestureDescription` requires `canPerformGestures="true"` in the service config.
- On some OEM ROMs (MIUI, One UI) you may need to enable "Background autostart" for
  the overlay to persist reliably.
